package gadgetsAutomation;

//Importing packages from java
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
//Importing packages from Apache
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//Importing packages from Selenium
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GadgetsAutomation {

	public static WebDriver driver;
	public static WebDriverWait wait;
	public static TakesScreenshot sc;
	public static String searchTerm, priceFrom, priceTo;
	
	
	public static void setupWebDriver(String browser) {
		//Create instance of Drivers to interact with the browser
		switch(browser.toLowerCase()) {
		case "chrome":
			driver=new ChromeDriver();
			break;
		case "edge":
			driver=new EdgeDriver();
			break;
		}
		//Initialize WebDriverWait with a timout of 10 seconds
		wait=new WebDriverWait(driver,Duration.ofSeconds(10));
	}
	
	public static void takeScreenshot(String fileName){
		//Create object for takesScreenshot calss.
		sc=(TakesScreenshot) driver;
		//Define output type for screenshot
		File screenshot=sc.getScreenshotAs(OutputType.FILE);
		//Define the destination to store the screenshots
		File destination=new File(System.getProperty("user.dir")+"\\Screenshots\\"+fileName+".png");
		//Rename screenshot for memory to destination
		screenshot.renameTo(destination);
	}
	
	public static void readExcel() throws FileNotFoundException, IOException {
		String filePath=System.getProperty("user.dir")+"\\TestData\\TestData.xlsx";
		FileInputStream file=new FileInputStream(filePath);
		Workbook workbook=new XSSFWorkbook(file);
		Sheet sheet=workbook.getSheet("Sheet1");
		Row row=sheet.getRow(1);
		searchTerm=row.getCell(0) !=null ? row.getCell(0).toString():"";
		priceFrom=row.getCell(1) !=null ? String.valueOf((int)row.getCell(1).getNumericCellValue()):"0"; 
		priceTo=row.getCell(2) !=null ? String.valueOf((int)row.getCell(2).getNumericCellValue()):"0";
		workbook.close();
		file.close();
		
	}
	public static void openWebsite() {
		//Navigate to the Snapdeal website
		String baseUrl="https://www.snapdeal.com/";
		driver.get(baseUrl);
		//Maximize the browser window
		driver.manage().window().maximize();
		//Wait for the push notification prompt to be visible
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("pushDenied")));
		} 
		catch(Exception e) {
			e.printStackTrace();
		}
		//Locate NOT NOW button and click it
		driver.findElement(By.id("pushDenied")).click();
		//Take a screenshot of the website's homepage
		takeScreenshot("homepage");
		
	}
	
	public static void searchBluetoothHeadphones() {
		//Locate search box by its ID and enter the search term "Bluetoot headphone"
		WebElement searchBox=driver.findElement(By.id("inputValEnter"));
		searchBox.sendKeys(searchTerm);
		//Take a screenshot after entering value in search box
		takeScreenshot("seachProduct");
		//Locate search button by its class name and click on it
		WebElement searchButton=driver.findElement(By.className("searchTextSpan"));
		searchButton.click();
	}
	
	public static void sortByPopularity() {
		//Locate the sort dropdown menu by its class name and click on it
		WebElement sortDrop=driver.findElement(By.className("sort-drop"));
		sortDrop.click();
		//Locate the "Popularity" option within the dropdown using xpath and click on it
		WebElement popularityOption=driver.findElement(By.xpath("//li[normalize-space()='Popularity']"));
		popularityOption.click();
		//Take a screenshot after applying the sorting by popularity
		takeScreenshot("sortResult");
	}
	
	public static void applyPriceFilter() {
		//Locate the "From" price input field by its name attribute and clear any existing value
		WebElement fromVal=driver.findElement(By.name("fromVal"));
		fromVal.clear();
		//Locate the "To" price input field by its name attribute and clear any existing value
		WebElement toVal=driver.findElement(By.name("toVal"));
		toVal.clear();
		//Set the price range by entering 700 as the minimum price
		fromVal.sendKeys(priceFrom);
		//Set the price range by entering 1400 as the maximum price
		toVal.sendKeys(priceTo);
		//Locat the "Go" button using XPath and clcik on it
		WebElement goButton=driver.findElement(By.xpath("//div[@class='price-go-arrow btn btn-line btn-theme-secondary']"));
		goButton.click();
		//Sleep for 1 seconds to ensure results have been updated
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			//Handle any interruptions during the sleep
			e.printStackTrace();
		}
		//Take a screenshot after applying the price filter
		takeScreenshot("priceFilter");
	}
	
	public static void getTopfive() {
		//Locate all product title using its class name and store it in headphone_title_list
		List<WebElement> headphone_title_list=driver.findElements(By.className("product-title"));
		//Locate all product price using its class name and store it in headphone_price_list
		List<WebElement> headphone_price_list=driver.findElements(By.className("product-price"));

		//Using for loop to traverse through the list
		for(int i=0;i<5;i++) {
			//Print the top five Bluetooth headphone product names and prices to the console
			System.out.println("Product Name: "+headphone_title_list.get(i).getText()+"\nPrice: "+headphone_price_list.get(i).getText());
		}	
		//Take a screenshot of the filterd result
		takeScreenshot("topFiveProduct");
	}
	
	public static void quitBrowser() {
		//Exist the browser
		driver.quit();
	}
	
}
