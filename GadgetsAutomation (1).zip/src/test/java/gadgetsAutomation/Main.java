package gadgetsAutomation;

//Importing packages from java
import java.io.FileNotFoundException;

import java.io.IOException;
//Import packages from TestNG
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;

public class Main {
	
	@BeforeClass
	@Parameters("browser")
	public void driverSetup(String br) {
		//Initialize the webDriver
		GadgetsAutomation.setupWebDriver(br);
	}
	
	@Test(priority=1)
	public static void launchWebsite() {
		//Open Snapdeal website
		GadgetsAutomation.openWebsite();
	}
	
	@Test(priority=2)
	public static void readData() throws FileNotFoundException, IOException {
		//Read data from excel using apache poi
		GadgetsAutomation.readExcel();
	}
	@Test(priority=3)
	public static void searchProduct() {
		//Search for Bluetooth headphones
		GadgetsAutomation.searchBluetoothHeadphones();
	}
	@Test(priority=4)
	public static void sortProduct() {
		//Sort products by popularity
		GadgetsAutomation.sortByPopularity();
	}
	@Test(priority=5)
	public static void filterProduct() {
		//Apply price filter 
		GadgetsAutomation.applyPriceFilter();
	}
	@Test(priority=6)
	public static void retriveProduct() {
		//Get top five product results
		GadgetsAutomation.getTopfive();
	}
	@Test(priority=7)
	public static void existBrowser() {
		//Close the entier browser
		GadgetsAutomation.quitBrowser();
	}
}
